import React from "react";
import { AgGridReact } from "ag-grid-react";
import {
  GridReadyEvent,
  GridApi,
  ColumnApi,
  RowSelectedEvent,
  FirstDataRenderedEvent,
} from "ag-grid-community";
import { ColDef } from "ag-grid-community/dist/lib/entities/colDef";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";

export interface DataGridProps {
  data: any[];
  columnDefs: ColDef[];
  multiple?: boolean;
  getRowNodeId?: (row: any) => string;
}

export const DataGrid = (props: DataGridProps) => {
  const data = props.data;
  const colDefs = props.columnDefs;

  const [gridApi, setGridApi] = React.useState<GridApi>();
  const [gridColumnApi, setGridColumnApi] = React.useState<ColumnApi>();
  const onGridReady = React.useCallback((event: GridReadyEvent) => {
    setGridApi(event.api);
    setGridColumnApi(event.columnApi);
  }, []);

  React.useEffect(() => {
    if (gridApi) {
      gridApi.setColumnDefs(colDefs);
      gridApi.setRowData(data);
    }
    if (gridColumnApi) {
      gridColumnApi.autoSizeAllColumns();
    }
  }, [props.data, props.columnDefs, gridApi, gridColumnApi]);

  const onCellFocused = (e: any) => {
    if (e && e.column && e.column.colDef && e.column.colDef.field === "email") {
      e.api.gridOptionsWrapper.gridOptions.suppressRowClickSelection = true;
    }
  };

  const onFirstDataRowRendered = (params: FirstDataRenderedEvent) => {
    if (gridColumnApi) {
      const colIds = gridColumnApi
        .getAllDisplayedColumns()
        .map((item) => item.getColId());
      gridColumnApi.autoSizeColumns(colIds);
    }
  };

  return (
    <div
      className="ag-container ag-theme-balham"
      style={{
        flexGrow: 1,
        height: "400px",
        width: "100%",
      }}
    >
      <AgGridReact
        onCellFocused={onCellFocused}
        rowSelection="single"
        onGridReady={onGridReady}
        getRowNodeId={props.getRowNodeId}
        onFirstDataRendered={onFirstDataRowRendered}
      />
    </div>
  );
};
