import { Button, Col, Form, InputNumber, Row, Select } from "antd";
import React, { useState } from "react";
import SearchTicker from "../atoms/SearchTicker";
import { Input } from "antd";
import { addTrade } from "../../redux/store";
import { useDispatch } from "react-redux";
import { v4 as uuidv4 } from "uuid";
import { Trade } from "../../models/Trade";
import { set } from "lodash";
import { Grid } from "ag-grid-community";
const { Option } = Select;

const TickerForm = () => {
  const defaultTrade: Trade = {
    buySell: "Buy",
    tif: "GTC",
    orderType: "Market",
  };
  const dispatch = useDispatch();
  const [newTrade, setNewTrade] = useState<Trade>(defaultTrade);

  const handleSubmit = (event: any) => {
    const clonedTrade = { ...newTrade };
    clonedTrade.id = uuidv4();
    dispatch(addTrade(clonedTrade));
    //TODO: do this on success
    setNewTrade(defaultTrade);
  };

  const updateTradeProperty = (
    propertyName: keyof Trade,
    value: string | number
  ) => {
    var updated = { ...set(newTrade, propertyName, value) };
    setNewTrade(updated);
  };

  return (
    <div>
      <span style={{ fontSize: "20px" }}>
        <b>Order Entry</b>
      </span>
      <Form>
        <Row>
          <Col sm={6}>
            <b>Action</b>
          </Col>
          <Col sm={6}>
            <b>Symbol</b>
          </Col>
          <Col sm={6}>
            <b>Qty</b>
          </Col>
          <Col sm={6}>
            <b>Price</b>
          </Col>
        </Row>

        <Row>
          <Col sm={6}>
            <Select
              defaultValue={newTrade.buySell}
              style={{ width: 120 }}
              onChange={(selection) =>
                updateTradeProperty("buySell", selection)
              }
            >
              <Option value="Buy">Buy</Option>
              <Option value="Sell">Sell</Option>
            </Select>
          </Col>
          <Col sm={6}>
            <SearchTicker
              onSelection={(ticker) => updateTradeProperty("symbol", ticker)}
            ></SearchTicker>
          </Col>
          <Col sm={6}>
            <InputNumber
              min={1}
              max={999}
              defaultValue={1}
              value={newTrade.position}
              onChange={(selection) =>
                updateTradeProperty("position", selection)
              }
            />
          </Col>
          <Col sm={6}>
            <InputNumber
              min={0.0}
              value={newTrade.price}
              onChange={(selection) => updateTradeProperty("price", selection)}
            />
          </Col>
        </Row>

        <Row>
          <Col sm={6}>
            <b>Order Type</b>
          </Col>
          <Col sm={12}>
            <b>TIF</b>
          </Col>
          <Col sm={6}>
            <b>Stop Price</b>
          </Col>
        </Row>
        <Row>
          <Col sm={6}>
            <Select
              defaultValue={newTrade.orderType}
              onChange={(selection) =>
                updateTradeProperty("orderType", selection)
              }
            >
              <Option value="Market">Market</Option>
              <Option value="Limit">Limit</Option>
            </Select>
          </Col>
          <Col sm={12}>
            <Select
              defaultValue={newTrade.tif}
              onChange={(selection) => updateTradeProperty("tif", selection)}
            >
              <Option value="GTC">GTC</Option>
              <Option value="DAY">DAY</Option>
              <Option value="FOK">FOK</Option>
              <Option value="IOC">IOC</Option>
            </Select>
          </Col>
          <Col sm={6}>
            <InputNumber
              min={0.0}
              value={newTrade.stop}
              onChange={(selection) => updateTradeProperty("stop", selection)}
            />
          </Col>
        </Row>
      </Form>
      <div> Comments</div>
      <Input
        value={newTrade.comments}
        onChange={(selection) =>
          updateTradeProperty("comments", selection.target.value)
        }
      />

      <Button type="primary" onClick={handleSubmit}>
        Submit
      </Button>
    </div>
  );
};

export default TickerForm;
