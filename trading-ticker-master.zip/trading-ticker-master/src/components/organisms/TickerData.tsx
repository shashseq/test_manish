import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Trade } from "../../models/Trade";
import { StoreState } from "../../redux/store";
import { DataGrid } from "../molecules/DataGrid";

const TickerData = () => {
  const trades = useSelector<StoreState, Trade[]>(
    (state: StoreState) => state.trades
  );
  const [columnDefs, setColumnDefs] = useState<any[]>([]);
  const [rows, setRows] = useState<Trade[]>([]);
  useEffect(() => {
    const columnDef = [
      { headerName: "BuySell", field: "buySell" },
      { headerName: "Symbol", field: "symbol" },
      { headerName: "Qty", field: "position" },
      { headerName: "TIF", field: "tif" },
      { headerName: "Type", field: "orderType" },
      { headerName: "Price", field: "price" },
      { headerName: "Stop Limit", field: "stop" },
      { headerName: "Comments", field: "comments" },
    ];
    setColumnDefs(columnDef);
    setRows(trades);
  }, [trades]);

  return (
    <div>
      Trade blotter
      <div>Count: {trades && trades.length}</div>
      <DataGrid
        data={rows}
        columnDefs={columnDefs}
        getRowNodeId={(row: any) => row?.make}
      ></DataGrid>
    </div>
  );
};

export default TickerData;
