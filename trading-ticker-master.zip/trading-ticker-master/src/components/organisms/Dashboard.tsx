import React from "react";
import SplitPane from "react-split-pane";
import TickerData from "./TickerData";
import TickerForm from "./TickerForm";

const Dashboard = () => {
  return (
    <div>
      <TickerForm />
      <TickerData />
    </div>
  );
};

export default Dashboard;
