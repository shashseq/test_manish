import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import "antd/dist/antd.css";
import { Input, AutoComplete } from "antd";

export interface SearchTickerProps {
  onSelection: (selection: string) => void;
}

const SearchTicker = (props: SearchTickerProps) => {
  const availableTickers = [
    "AAPL",
    "MSFT",
    "GOOGL",
    "VZ",
    "MMM",
    "NFLX",
    "FB",
    "TWTR",
    "AMZN",
    "EBAY",
  ];
  const [options, setOptions] = useState<any>([]);

  useEffect(() => {
    const searchOptions = availableTickers.map((item) => {
      return { value: item };
    });
    setOptions(searchOptions);
  }, []);

  const handleSearch = (value: any) => {
    //setOptions(value ? searchResult(value) : []);
  };

  const onSelect = (value: any) => {
    props.onSelection(value);
  };

  return (
    <AutoComplete
      dropdownMatchSelectWidth={252}
      style={{
        width: 300,
      }}
      options={options}
      onSelect={onSelect}
      onSearch={handleSearch}
    >
      <Input.Search size="large" placeholder="input here" enterButton />
    </AutoComplete>
  );
};

export default SearchTicker;
