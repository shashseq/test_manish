import React from 'react';
import logo from './logo.svg';
import './App.css';
import SplitPane from "react-split-pane";
import Dashboard from "./components/organisms/Dashboard";

function App() {
  return (
    <div className="App">
      <Dashboard></Dashboard>
    </div>
  );
}

export default App;
