import { combineReducers, createStore } from "redux";
import { Trade } from "../models/Trade";

export interface StoreState {
  trades: Trade[];
}

export const initialState: StoreState = {
  trades: [],
};

// actions.js
export const addTrade = (trade: Trade) => ({
  type: "ADD_TRADE",
  payload: trade,
});

// reducers.js
export const trades = (state = initialState.trades, action: any) => {
  switch (action.type) {
    case "ADD_TRADE":
      return [...state, action.payload];
    default:
      return state;
  }
};

export const reducers = combineReducers({
  trades,
});

// store.js
export function configureStore(initialState = {}) {
  const store = createStore(reducers, initialState);
  return store;
}

export const store = configureStore();
