export interface Trade {
  id?: string;
  buySell?: string;
  symbol?: string;
  position?: number;
  tif?: string;
  orderType?: string;
  price?: number;
  stop?: number;
  comments?: string;
}
